package Module.Classe;

import Module.Interface.IMatrice;


public class CMatrice implements IMatrice {
    
    char[][] array;

    int x;
    
    public CMatrice() {
        
        this.x = 3;
        this.array = new char[x][x];
        initArray();
    }
    
    public CMatrice(int size) {
        
        this.x = size;
        this.array = new char[size][size];
        initArray();
    }
    
    private void initArray() {
        
        for(int i = 0; i < x; i++) {
            for(int j = 0; j < x; j++) {
                array[i][j] = ' ';
            }
        }
    }

    @Override
    public void setMatrice(int x, int y, char symbole) {       
        array[x][y] = symbole;
    }

    @Override
    public char getMatrice(int x, int y) {
        return array[x][y];
    }

    @Override
    public int getSize() {
        return x;
    }
    
}

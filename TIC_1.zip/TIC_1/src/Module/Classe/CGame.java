package Module.Classe;

import Module.Interface.IGame;

public class CGame implements IGame {

    @Override
    public void jouer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean conitnuer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean reload() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void win(boolean win, int joueur) {
        
        if(joueur == 1 && win == true) {
            System.err.println("joueur 1 win");
        } else if(joueur ==2 && win == true) {
            System.err.println("joueur 2 win");
        }
    }

    @Override
    public boolean win() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

package Module.Classe;

import Module.Interface.ISearch;


public class CSearch implements ISearch{
    
    CMatrice matrice;
    char croix, cercle;

    public CSearch(CMatrice matrice, char croix, char cercle) {
        
        this.matrice = matrice;
        this.croix = croix;
        this.cercle = cercle;
    }
    
    

    @Override
    public boolean searchLigne(int fixe) throws CException {
        
        boolean nbOccurence = false;
        
        int indiceX = 0;
        int indiceO = 0;
        
        for(int i = 0; i <= matrice.getSize() - 1; i++ ) {
            
            if(i > matrice.getSize()) {
                throw new CException(i);
            }
            
            if(matrice.getMatrice(i,fixe) == croix) {
                indiceX++;
            } else if(matrice.getMatrice(i,fixe) == cercle) {
                indiceO++;                
            }          
        }
        
        System.err.println("search x : " + indiceX);
        nbOccurence = occurence(nbOccurence, indiceX, indiceO);
        
        return nbOccurence;
    }

    @Override
    public boolean searchColonne(int fixe) throws CException {
        
        boolean nbOccurence = false;
        
        int indiceX = 0;
        int indiceO = 0;
        
 
        for(int i = 0; i <= matrice.getSize() - 1; i++ ) {  
            
            if(i > matrice.getSize()) {
                throw new CException(i);
            }
            
            if(matrice.getMatrice(fixe,i) == croix) {
                   indiceX++;
            } else if(matrice.getMatrice(fixe,i) == cercle) {
                indiceO++;                
            }          
        }        
        
        
        nbOccurence = occurence(nbOccurence, indiceX, indiceO);
        
        return nbOccurence;
    }

    @Override
    public boolean searchDiagonale_1() throws CException{
        
        boolean nbOccurence = false;
        
        int indiceX = 0;
        int indiceO = 0;
        
        for(int i = 0; i <= matrice.getSize() - 1; i++) {
            
            if(i > matrice.getSize()) {
                throw new CException(i);
            }
            
            System.err.println("ici : " + matrice.getMatrice(i, i));
            if(matrice.getMatrice(i,i) == croix) {
                indiceX++;
            } else if(matrice.getMatrice(i,i) == cercle) {
                indiceO++;
            } 
        }
        
        nbOccurence = occurence(nbOccurence, indiceX, indiceO);

        return nbOccurence;
    }

    @Override
    public boolean searchDiagonale_2() throws CException {
        
        boolean nbOccurence = false;  
        
        int indiceX = 0;
        int indiceO = 0;
        
        
        for(int i = matrice.getSize() - 1, j = 0; i >= 0; i--, j++) {
            
            if(i > matrice.getSize()) {
                throw new CException(i);
            }
            
            if(matrice.getMatrice(i,j) == croix) {
                indiceX++;
             
            } else if(matrice.getMatrice(i,j) == cercle) {
                indiceO++;
            } 
        }
        
        nbOccurence = occurence(nbOccurence, indiceX, indiceO);

        return nbOccurence;    
    }

    @Override
    public boolean occurence(boolean nbOccurence, int nbX, int nbO) {
    
        if(nbX == matrice.getSize() || nbO == matrice.getSize()) {
            nbOccurence = true;
            System.err.println("hello");
        }
                
        return nbOccurence;
    }
    
}

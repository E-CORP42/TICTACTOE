package Module.Classe;


public class CException extends Exception {

    public CException(int indice) {
        
        System.err.println("Sortie de tableau a l'indice : " + indice);
    }
    
    
    
}

package Module.Interface;

/**
    Définit les méthode lors du jeux

    @version 0.0
    
*/

public interface IGame {
    
    /**
        =========================== jouer ===========================
    
            Lance le jeux
    */
    
    public void jouer();
    
    /**
        =========================== continuer ===========================
    
            permet au jeu de continuer
            
        @return 
    */
    
    abstract boolean conitnuer();
    
    /**
        =========================== reload ===========================
    
            recharge le jeu
            
        @return True/false
    */
    
    abstract boolean reload();
    
    /**
        =========================== reload ===========================
    
            recharge le jeu
            
        @return 
    */
    
    abstract boolean win();
    
}

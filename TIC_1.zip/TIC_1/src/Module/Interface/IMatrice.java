package Module.Interface;

/**
    Définit la matrice de base pour un TICTACTOE 3x3

    @version 0.0
*/


public interface IMatrice {
    
    /**
        =========================== setMatrice ===========================
    
            Modifie la valeur de la case (x,y) de la matrice
    
        @param x
        @param y
        @param symbole
    */
    
    public void setMatrice(int x, int y, char symbole);
    
    /**
        =========================== getMatrice ===========================
    
            Récupère la valeur de la case (x,y) de la matrice
    
        @param x
        @param y
    */
    
    public char getMatrice(int x, int y);
    
    /**
        =========================== getMatrice ===========================
    
            Récupère la taille de la matrice
    
        * @return la taille de la matrice carré
    */
    
    public int getSize();
    
}

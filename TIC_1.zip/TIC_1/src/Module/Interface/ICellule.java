package Module.Interface;

/**
    Définit une cellule du tableau
    

    @version 0.0
    
*/

public interface ICellule {
    
    /**
        *=========================== search ===========================
        * 
            *Permet de savoir si le pixel toucher
            *est dans un carré précis
    
        *@param pixelX 
        *@param pixelY
    */
    
    public void serach(int pixelX, int pixelY);
    
     /**
        =========================== InLigne_One ===========================
    
            Permet de savoir si le pixel toucher
            est dans un carré précis
    
        @param pixelX 
        @param pixelY
    
        @return False/True si le carré se trouve dans la ligne 1
    */
    
    abstract boolean InLigne_One(int pixelX, int pixelY);
    
    /**
        =========================== InLigne_Two ===========================
    
            Permet de savoir si le pixel toucher
            est dans un carré précis
    
        @param pixelX 
        @param pixelY
    
        @return False/True si le carré se trouve dans la ligne 2
    */
    
    abstract boolean InLigne_Two(int pixelX, int pixelY);
    
    /**
        =========================== InLigne_Three ===========================
    
            Permet de savoir si le pixel toucher
            est dans un carré précis
    
        @param pixelX 
        @param pixelY
    
        @return False/True si le carré se trouve dans la ligne 3
    */
    
    abstract boolean InLigne_Three(int pixelX, int pixelY);


    

    
}

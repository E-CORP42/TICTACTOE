/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Panneau;

import Graphique.JPanel.Panel_Menu;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author johan
 */
public class DrawMap extends Panel_Menu {
    
    private int witdh, hight, nbCase;
    private int x,y;
    
    public void paintComponent(Graphics g){
        
        super.paintComponent(g);
        
        divi();

        for(int i = 0; i <= nbCase-1; i++) {

            g.drawLine(x*i, 0, x*i, witdh);
            g.drawLine(0, y*i, witdh, y*i);
            
        }
    }
    
    private void divi() {
        
        x = witdh/nbCase;
        y = hight/nbCase;
    }
    
    public int setWitdh(int width) {
        return this.witdh = width;
    }
    
    public int setHight(int hight) {
        return this.hight = hight;
    }
    
    public int setNbCase(int nbCase) {
        return this.nbCase = nbCase;
    }
    
}

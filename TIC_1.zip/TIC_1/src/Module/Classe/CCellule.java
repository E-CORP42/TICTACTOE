package Module.Classe;

import Module.Interface.ICellule;


public class CCellule implements ICellule{
    
    int indiceX = 0;
    int indiceY = 0;
    
    int sizeX = 0;
    int sizeY = 0;

    public CCellule() {
    }
    
    public void serach(int pixelX, int pixelY, int Case, int width, int hight) {
        
        int x = width/Case;
        int y = hight/Case;
        
        System.err.println(x);
  
        
        boolean found = false;
 
        for(int i = 0; i < Case+1; i++) {
            for(int j = 0; j < Case+1; j++) {
                
                
                if(pixelX > x*i  && pixelX < (i+1)*x  && pixelY > y*j && pixelY < (j+1)*y ) {
  
                    found = true;
                    indiceX = i;
                    indiceY = j;         
                }   
            }  
        }
        
        System.err.println(indiceX);
    }
    
    
    
    public int getSizeX() {
        return sizeX;
    }
    
    public int getSizeY() {
        return indiceY;
    }
    
    public int getIndiceX() {
        return indiceX;
    }
    
    public int getIndiceY() {
        return indiceY;
    }

    @Override
    public boolean InLigne_One(int pixelX, int pixelY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean InLigne_Two(int pixelX, int pixelY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean InLigne_Three(int pixelX, int pixelY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void serach(int pixelX, int pixelY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

package Module.Classe;

import Module.Interface.IPlayer;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class CPlayer implements IPlayer{
    
    Image image;
    char symbole;

    public CPlayer(String symbole,char sym) throws IOException {
        
        this.symbole = sym;
        this.image = ImageIO.read(new File("/Users/johan/Documents/E-CORP/TIC/src/Image/" + symbole + ".jpg"));     
    }
    
    @Override
    public Image getImage() {
        return this.image;
    }
    
    public char getSymbole() {
        return this.symbole;
    }
    

    
}

package Module.Classe;

public class CData {
    
    private final char croix = 'X';
    private final char cercle = 'O';

    public CData() {
        
    }
    
    public char getCroix() {
        return croix;
    }
    
    public char getCercle() {
        return cercle;
    }
    
    
    
}

package Module.Interface;

import java.awt.Image;

/**
    Définit un joueur

    @version 0.0
*/
public interface IPlayer {
    
        /**
        =========================== getImage ===========================
    
            Recupere l'image joeur
     
        @return   
    */
    public Image getImage();
    
}

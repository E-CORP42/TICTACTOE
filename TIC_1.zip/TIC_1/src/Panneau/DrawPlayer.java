/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Panneau;

import Graphique.JPanel.Panel_Menu;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author johan
 */
public class DrawPlayer extends Panel_Menu {
    
    int x = 0, y = 0;
    Image img;
    DrawMap map;
    JFrame pan;
    Graphics g;

    public DrawPlayer(Graphics g) {
        
        this.g = g;
        
    }
    
    
    
    public void paintComponent(){
        
        super.paintComponent(this.g);
        
         g.drawImage(img, x, y, null);
         g.draw3DRect(100, 50, 150, 100, true);
         //JLabel picLabel = new JLabel(new ImageIcon(img));
         this.map =  new DrawMap();
         map.setHight(this.getHeight()); //Donne la largeur a la map
        map.setWitdh(this.getWidth()); //Donne la hauteur a la map
        map.setNbCase(3);
        pan.update(g);
         
         

    }
    
    
    
    public void setX(int x) {
        this.x = x;
    }
    
    public void setY(int y) {
        this.y = y;
    }
    
    public void setImg(Image img) {
        this.img = img;
    }
    
    public void setMap(JFrame pan) {
        this.pan = pan;
    }
    
    
}

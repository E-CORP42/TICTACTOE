package Module.Interface;

import Module.Classe.CException;

/**
    Définit les méthode de recherches

    @version 0.0
*/

public interface ISearch {
    
    /**
        =========================== searchLigne ===========================
    
            Recherche les différente valeurs sur la ligne
     * @param fixe
        @return 
    */
    
    public boolean searchLigne(int fixe) throws CException;

    /**
        =========================== searchColonne ===========================
    
            Recherche les différente valeurs sur la Colonne
     * @param fixe            
        @return
    */
    
    public boolean searchColonne(int fixe) throws CException;
    
    /**
        =========================== searchDiagonale_1 ===========================
    
            Recherche les différente valeurs sur la Diagonale 00 à 22
     
        @return    
    */
    
    public boolean searchDiagonale_1() throws CException;
    
    /**
        =========================== searchDiagonale_2 ===========================
    
            Recherche les différente valeurs sur la Diagonale 02 à 22
    
        @return    
    */
    
    public boolean searchDiagonale_2() throws CException;
    
    /**
        =========================== searchDiagonale_2 ===========================
    
            Nombre de x et O
     * @param nbOccurence            
        * @param nbX    
        * @param nbO   
        * 
        @return    
    */
    
    abstract boolean occurence(boolean nbOccurence, int nbX,int nbO);
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Graphique.JPanel;

import Module.Classe.CCellule;
import Panneau.DrawMap;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import javax.swing.JFrame;

/**
 *
 * @author johan
 */
public final class Panel_jeu extends javax.swing.JPanel implements MouseListener {

    /**
     * Creates new form Panel_jeu
     * @throws java.io.IOException
     */
    
    private int MouseX, MouseY;
    private int Case;
    private int width,hight;
    
    private JFrame fen;
            
            
    public Panel_jeu(JFrame fen) throws IOException {
        initComponents();
        this.fen = fen;
        
        


        
        
        
       
               
    }
   


    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();

        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                formMouseClicked(evt);
            }
        });

        jButton1.setText("jButton1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(110, 110, 110))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jButton1)
                .addContainerGap(207, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseClicked

       
    }//GEN-LAST:event_formMouseClicked

    public int getMouseX() {
        return MouseX;
    }
    
    public int getMouseY() {
        return MouseY;
    }
    
    public int getCase() {
        return Case;
    }
    
    public int getwidth() {
        return width;
    }
    
    public int gethight() {
        return hight;
    }
    
    public void setCase(int Case) {
         this.Case = Case;
    }
    
    public void setwidth(int width) {
         this.width = width;
    }
    
    public void sethight(int hight) {
        this.hight = hight;
    }

    
    public void mouseClicked(MouseEvent e) {
        
        int x = 0, y = 0;
                
        MouseX = e.getX();       
        MouseY = e.getY();
        
        CCellule cellule = new CCellule();
        
        
        cellule.serach(MouseX, MouseY, Case, width, hight);
        
        x = cellule.getIndiceX();
        y = cellule.getIndiceY();
        
        //this.paint(getGraphics());
        
        Graphics2D g2d = (Graphics2D) this.getGraphics();

      for(int i = 0; i<4; i++)
      {
         g2d.setColor(Color.ORANGE);
         g2d.setStroke(new BasicStroke(3));
         g2d.drawOval(78+i*70, 106+10*50, 35, 35);
      }
        
       
        
       
        
    }
    
    //public void paintComponent(Graphics g){
       
        
        //g.draw3DRect(10, 10, 40, 40, true);
    //}
    


    @Override
    public void mousePressed(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}

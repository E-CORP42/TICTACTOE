/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Panneau;

import Graphique.JPanel.Panel_Menu;
import Module.Classe.CPlayer;
import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author johan
 */
public class PMenu extends Panel_Menu {

    private int posX = 0;
    private int posY = 0;
    
    private CPlayer player;

    
    public void paintComponent(Graphics g){
        g.drawImage(player.getImage(), posX, posY, null);
    }
    
    public void setPosX(int posX) {
        this.posX = posX;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }
    
    public void setPlayer(CPlayer player) {
        this.player = player;
    }
    
    
    
    

    
}
